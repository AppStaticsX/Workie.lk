class AppDimension {
  static const double paddingDefault = 10.0;

  // Letter space default
  static const double defaultLetterSpace = 1.0;

  // Font sizes
  static const double defaultFontSize = 16.0;
}
